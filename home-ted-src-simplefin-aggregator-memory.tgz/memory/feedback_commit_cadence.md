---
name: feedback_commit_cadence
description: Don't commit once per conversational round; commit when a review tool needs committed code, or when the work is done.
metadata:
  type: feedback
---

The user interrupted a series of small commits, one per exchange of an
iterative discussion: "you do not need to commit on every round of our
conversation. please don't do that in the future. that was only for rounds
with coderabbit."

**Why:** The project's review cycle requires committing mid-cycle only because
an AI review tool reads committed code, so a fix has to land as a commit to be
re-reviewed. That is a tool constraint, not a working style. Applied to an
ordinary back-and-forth with the user it produces history that records the
conversation instead of the change, and the user then has to ask for it to be
squashed.

**How to apply:** During a discussion, edit and verify but leave the work
uncommitted until the user asks, or until a review tool needs it committed.
When several rounds of feedback have landed, offer to fold them into one
commit rather than leaving a trail of them. See
[[feedback_verification_suite]] — running the checks every round is still
right; it is only the committing that is not.
