---
name: feedback-basedpyright-clean
description: "basedpyright clean means zero warnings too, not just zero errors — fix or explicitly ignore each one"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d61853aa-021f-4c3f-bb78-dba73c675b21
  modified: 2026-09-02T07:08:49.788Z
---

"basedpyright clean" means no warnings left unaddressed, not just no errors. Do not let a category of warning (e.g. `reportAny`) accumulate across files just because one instance of it was tolerated earlier — each occurrence needs an actual decision.

**Why:** After Step 3 I reported "0 errors, 28 warnings" as an acceptable clean state on the reasoning that the warnings were "the same category already accepted in Step 2." The user corrected this directly: that reasoning is exactly backwards — tolerating one `reportAny` doesn't license letting them spread everywhere.

**How to apply:** For every basedpyright warning:
- If there's a real static type available (e.g. `request.app.state.foo` where `foo`'s type is known from how it's set), make it explicit — a local type annotation, `cast()`, or restructuring to avoid the untyped access — rather than leaving it as `Any`.
- Only when the code is genuinely, unavoidably untyped at that point (a third-party boundary with no useful stub, or a deliberate expedient shortcut) suppress it with `# pyright: ignore[rule1, rule2]` and a short reason — never a bare ignore, never reached for reflexively.
- Re-run `basedpyright` after every edit (see [[feedback_verification_suite]]) and treat its warning count as something to actually drive to zero (via fix-or-justified-ignore), not just glance at and accept if it "looks similar to before."
