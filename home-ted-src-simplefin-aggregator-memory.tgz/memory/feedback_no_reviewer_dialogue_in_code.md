---
name: feedback_no_reviewer_dialogue_in_code
description: Don't leave comments arguing with code reviewers; the code carries essential comments, not the history of who objected to what.
metadata:
  type: feedback
---

The user, after a step went through several AI review passes: "don't litter
the code with comments justifying the outcome of conversations with code
reviewers. the code should stand on its own with just essential comments, not
extraneous history."

**Why:** A comment written to pre-empt a reviewer's objection is addressed to
someone who will never read it. The next reader has no idea a debate happened,
does not care who won, and is left with paragraphs defending a line against a
challenge that is not in front of them. It is the same failure as writing up
rejected alternatives.

**How to apply:** Once a review round settles, rewrite the affected comments as
if the code had always looked this way. Keep the reasoning a future maintainer
needs to avoid re-litigating a decision; drop everything that only makes sense
as an answer to a reviewer. The disposition of a finding belongs in the reply
to the reviewer and, if it changed the design, in the commit message — not in
the source. See [[feedback_no_rejected_alternatives]] and
[[feedback_comments_state_why_not_what]].
