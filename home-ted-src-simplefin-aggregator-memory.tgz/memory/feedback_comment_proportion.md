---
name: feedback_comment_proportion
description: Size a comment to the code it explains; lead with the subject, not the conclusion.
metadata:
  type: feedback
---

The user rejected a 12-line docstring on a two-line predicate as "too verbose",
and separately flagged a comment whose first sentence ("Rejected, not
normalized, like every other non-canonical form here.") stated a conclusion
before naming its subject: "the reader has to look 10 lines down to figure out
that the comment is about rejecting . and .. segments in the path."

**Why:** This is not a preference for terseness in general — the module
docstrings and the tricky-branch comments in `url_validation.py` are long and
the user keeps them. The rule is proportion and ordering: a small helper gets a
small comment, and any comment opens by naming what it is about.

**How to apply:** Match comment length to the subtlety of the code, not to how
much you happen to know about it. Open with the subject ("Reject a `.` or `..`
path segment rather than resolving it"), then the reasoning. Long rationale is
welcome where a reader would otherwise re-litigate a decision — including
answering a question the user actually asked, e.g. "why not normalize instead"
belongs in situ. See [[feedback_verification_suite]].
