---
name: feedback_comments_state_why_not_what
description: A comment states why the code does something, only when non-obvious; it never restates what the code does.
metadata:
  type: feedback
---

The user, reviewing a module whose comment-to-code ratio had grown alarming:
"comments should not vacuously state what the code does; they should state why
the code does it, and only if it is non-obvious." And on the effect of getting
this wrong: "a reader will conclude that you don't really know what the module
is supposed to accomplish, so you are explaining the intricacies of the
implementation rather than the principles it adheres to, and suspect that
there are in fact no principles to begin with."

**Why:** A comment restating the code is noise that ages badly, and a module
full of them reads as though it has intricacies instead of principles. Density
is itself a signal: if the logic needs that much narration, the logic is
probably wrong, or the module's purpose was never articulated.

**How to apply:** Ask what a reader would get wrong without the comment. If
nothing, delete it. Prefer making the code self-documenting to explaining it.
Put the module's principles in its docstring — stated with the limits that
actually apply, since a rule with a stated limit is clearer than a rule
defended by machinery — and let the body carry only the non-obvious *why*. See
[[feedback_prose_leads_with_the_point]] and [[feedback_comment_proportion]].
