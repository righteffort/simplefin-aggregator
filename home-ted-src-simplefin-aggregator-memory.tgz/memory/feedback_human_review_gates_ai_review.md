---
name: feedback-human-review-gates-ai-review
description: Present work and stop; only a human reply starts the AI reviewers or a squash
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3e275f51-9a66-45c0-9b17-0d83f648355a
  modified: 2026-09-06T06:34:59.987Z
---

When a workflow says to review with the human before running AI reviewers, that is a gate, not a courtesy. Present what changed, end the turn, and wait. Do not launch CodeRabbit or /code-review in the same turn as the presentation — not even "to get them started while you read". The user, after I did exactly that: "my instructions say you are to wait for me to review before handing off to code rabbit. how can they be written so that future sessions don't miss that".

**Why:** The user's review routinely changes scope or direction, so reviews launched first are spent on a version that is about to change. The reviewers are also rationed — the CodeRabbit CLI allows three reviews per window, and I exhausted them mid-task once already.

**How to apply:** A turn that presents work and then keeps acting has not stopped, whatever it said while presenting. The same gate applies before squashing after a review round — see [[feedback_review_delta_before_squash]]. Related: [[feedback_commit_cadence]], on not committing for conversation's sake.
