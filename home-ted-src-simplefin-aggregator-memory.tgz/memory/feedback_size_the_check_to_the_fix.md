---
name: feedback-size-the-check-to-the-fix
description: "Prefer the cheap check that answers the question; don't build machinery larger than the code it guards"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3e275f51-9a66-45c0-9b17-0d83f648355a
  modified: 2026-09-06T06:05:45.228Z
---

Take the simplest mechanism that answers the question, and let it be wrong at the margins. The user on a probe-file writability check: "why are we creating a tmp file in `check_can_save` instead of simply running stat on the directory? i understand there are corner cases, but if it is owner writable i'd argue that is close enough. if it fails because someone else owns it, oh well." The same judgment applies to test scaffolding: a one-keyword fix does not earn a subprocess harness.

**Why:** A faithful check that acts on the filesystem, or a harness that spawns a child interpreter to prove an argument was passed, costs more to read and maintain than the failure it prevents. Machinery reads as intricacy standing in for judgment.

**How to apply:** Ask what the cheap version gets wrong and whether that case matters here — a single-user CLI does not need to be right about another user's permissions. Where a check needs more machinery than the code it checks, state the intent in a comment and leave it untested. Sibling of [[feedback_comment_proportion]]; see also [[feedback_tests_describe_behavior]].
