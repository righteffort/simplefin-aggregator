---
name: feedback_tests_describe_behavior
description: Tests and their comments state required behavior, never that the code matches its dependency.
metadata:
  type: feedback
---

After a refactor that moved `url_validation.py` onto `httpx2.URL`, the user
found the test file "chock-full of 'this test tests that the implementation
does what httpx does' rather than describing the desired behavior they test
for" — case-folding justified by "httpx2 lowercases the scheme and host", a
default port by "which httpx2 drops", bare `?`/`#` by "httpx2's .query and
.fragment are both empty here". One test asserted a dependency's behavior
outright and was deleted.

**Why:** "Tests are not about confirming that the code is narrowly implemented
using the particular design & dependency choices; they are about confirming
that the code behaves correctly, regardless of how it is implemented." A test
justified by the library it happens to use goes stale the moment the library
is swapped, and it never said what the code was supposed to do.

**How to apply:** Write the expectation as a rule about the domain — "the
scheme's default port names the same origin as no port at all", "a bare
delimiter with nothing after it is still a query string". Name no dependency
in a test comment, docstring, or name, and never assert on a dependency's own
output. A dependency's quirk belongs in a comment in the implementation, at
the call site that relies on it. Watch for this in every test file, not just
the one being reviewed. See [[feedback_comment_proportion]] and
[[feedback_no_rejected_alternatives]].
