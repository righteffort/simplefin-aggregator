---
name: feedback_prose_leads_with_the_point
description: Comments and commit messages are written for their audience and lead with the key point, not assembled as a record of how the code got here.
metadata:
  type: feedback
---

The user, on a commit message and several comments that had grown across
review rounds: "non-trivial comments and commit messages should not be a mere
accretion of history. read them from the perspective of the audience and lead
with the key point before providing any essential details."

**Why:** Text that grows one round at a time ends up ordered by when each part
was learned rather than by what the reader needs first. A commit message that
narrates the review sequence, or a comment that answers objections in the
order they arrived, makes the reader reconstruct the point instead of being
handed it.

**How to apply:** Before writing either, ask who reads this and what they need
in the first sentence — for a commit message, someone in `git log` asking why
the code looks like this; for a comment, someone about to change the line
below it. Lead with that, then the details that are genuinely needed.
Organize by topic, never chronologically. When several rounds of edits have
landed, rewrite the whole thing from the current state rather than appending
to it. See [[feedback_comment_proportion]] and
[[feedback_comments_state_why_not_what]].
