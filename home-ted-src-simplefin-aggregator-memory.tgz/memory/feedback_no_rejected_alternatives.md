---
name: feedback_no_rejected_alternatives
description: Don't write up rejected alternatives in comments or docs; state what the code does.
metadata:
  type: feedback
---

Do not put "we tried X but decided against it" narratives into comments,
docstrings or design docs. State what the code does and why it is right. The
user called this out as a habit of mine: I had written a plan-doc section
framing a normalization change as a concession, plus a comment paragraph
walking through `urljoin`, `posixpath.normpath` and `httpx2.URL` as rejected
options.

**Why:** a reader needs the current design, not its history. Apologetic
framing also misreads the change — dropping the "never repaired" rule for
`httpx2.URL` normalization was strictly an improvement and a simplification,
since the original rule existed for simplicity rather than correctness, and
normalizing achieves both.

**How to apply:** write the positive statement ("matching compares the
normalized form, which is also the form that gets requested"). Omit the
alternatives entirely unless a reader would otherwise actively re-introduce
the rejected one — and then one clause, not a paragraph. Never hedge a
deliberate improvement as a concession or a relaxation. Related:
[[feedback_comment_proportion]].
