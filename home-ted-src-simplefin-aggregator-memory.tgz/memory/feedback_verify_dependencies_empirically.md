---
name: feedback-verify-dependencies-empirically
description: "Claims about a dependency's runtime behaviour must be checked by running it, not by reading its source"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3e275f51-9a66-45c0-9b17-0d83f648355a
  modified: 2026-09-06T06:05:28.794Z
---

When stating what a third-party library does at runtime — whether an exception message embeds a URL, what encoding a call defaults to — run it and show the output. Reading the source is how the belief forms; executing it is what settles it. The user asked directly: "by reading the code or validating empirically? i'd be more confident in empirical validation."

**Why:** A correct-looking read can still be wrong about which code path runs, and the cost of checking is a few lines against a loopback fake. The reverse also bites: in this project a reviewer's confident reproduction of a locale bug (`LC_ALL=C`) did not reproduce, because PEP 538 coerces that locale to C.UTF-8 — the defect was real, the stated repro was not.

**How to apply:** Before asserting a dependency's behaviour in a report, a comment, or a commit message, write the smallest script that provokes it and quote the result. Keep it on loopback per [[feedback_no_outbound_network]]. Applies to reviewer findings too — verify their repro, not just their conclusion, per [[feedback_review_delta_before_squash]].
