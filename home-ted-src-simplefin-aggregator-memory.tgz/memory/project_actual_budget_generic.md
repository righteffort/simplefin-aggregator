---
name: project-actual-budget-generic
description: "simplefin-aggregator's client app is generic; Actual Budget is only the motivating example, not a special case"
metadata: 
  node_type: memory
  type: project
  originSessionId: d61853aa-021f-4c3f-bb78-dba73c675b21
  modified: 2026-09-03T01:15:38.356Z
---

simplefin-aggregator can be used by any SimpleFIN client app, not just Actual Budget. Actual Budget is only the motivating use case that prompted the project.

**Why:** The user corrected wording in PROMPT.md that had implied Actual Budget specifically, clarifying the aggregator is generic.

**How to apply:** Keep "client"/"client app" (see [[project_terminology]]) generic in code, comments, docs, and commit messages — mention Actual Budget only as an example, never bake it into naming, logic, or assumptions about client behavior.
