---
name: feedback-no-outbound-network
description: "Never make real outbound network calls during manual/live verification, even when the sandbox allows it"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d61853aa-021f-4c3f-bb78-dba73c675b21
  modified: 2026-09-02T07:05:31.021Z
---

Do not make real outbound network requests to third-party hosts as part of "manual" or "live" verification in this project, even when the sandbox happens to have outbound network access.

**Why:** After Step 3, I ran the live server against the real `beta-bridge.simplefin.org` to smoke-test `/simplefin/accounts` and `/simplefin/info` end-to-end (this sandbox unexpectedly had outbound access). The user corrected this: outbound access should be treated as disallowed for manual tests regardless of what the sandbox permits.

**How to apply:** For "live"/manual verification of network-calling code (CLI `claim`, provider fetch/accounts/info paths, anything hitting a real host), use loopback-only fakes instead — e.g. run a local stand-in HTTP server on `127.0.0.1`, or rely on `httpx2.MockTransport`/`TestClient` integration tests — never point the real app at a real external hostname, even a legitimate one like the SimpleFIN demo bridge. If a genuinely-live check against a real provider is ever wanted, ask the user first rather than doing it by default.
