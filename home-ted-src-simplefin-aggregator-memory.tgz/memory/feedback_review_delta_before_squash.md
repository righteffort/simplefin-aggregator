---
name: feedback-review-delta-before-squash
description: Hand the user a reviewable diff of what AI review changed before squashing the step into one commit
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3e275f51-9a66-45c0-9b17-0d83f648355a
  modified: 2026-09-06T06:05:36.680Z
---

After an AI review round, the user wants to review the delta between what I wrote and what the reviewers changed — as a diff or commit, not only as prose. Squash the step only after that sign-off. Their words: "you did not give me a single commit to review that encapsulates the delta between your pre-coderabbit work and the current state!"

**Why:** The disposition list says what I claim changed; the diff says what actually did. Squashing first destroys exactly the artifact under review, and `git reset --soft` leaves the pre-review commit reachable only through the reflog.

**How to apply:** Tag or branch the pre-review commit before the cycle starts. At sign-off time offer `git diff <pre-review> <current>`, or better a real commit carrying that delta: `git branch step-review-delta $(git commit-tree <current>^{tree} -p <pre-review> -m "...")` — it can be read, commented on, and fed to a reviewer like any other commit. Squash after. Relates to [[feedback_commit_cadence]] (mid-cycle commits are scaffolding) and [[feedback_prose_leads_with_the_point]] (the squashed message describes the step, not the review rounds).
