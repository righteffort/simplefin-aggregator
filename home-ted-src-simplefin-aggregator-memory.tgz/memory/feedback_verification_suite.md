---
name: feedback-verification-suite
description: "Always include basedpyright in the verification loop, not just ruff/pytest"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d61853aa-021f-4c3f-bb78-dba73c675b21
  modified: 2026-09-02T06:29:30.699Z
---

After any code edit in simplefin-aggregator, run the full verification trio — `uv run ruff format --check .`, `uv run ruff check .`, `uv run pytest -q`, **and `uv run basedpyright`** — not just a subset.

**Why:** The user explicitly corrected this after I ran only ruff+pytest following a small test refactor and omitted basedpyright. PROMPT.md requires basedpyright strict-mode-clean as a project-wide deliverable, so skipping it during routine verification risks silently regressing type-checking cleanliness between checks.

**How to apply:** Treat basedpyright as a mandatory step in every "verify my change" pass in this repo, on equal footing with ruff and pytest, even for small/mechanical edits (e.g. pulling a lambda into a named function) that seem unlikely to affect typing.
