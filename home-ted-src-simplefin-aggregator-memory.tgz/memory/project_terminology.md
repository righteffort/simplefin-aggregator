---
name: project-terminology
description: "This project calls the app talking to the aggregator \"client\" / \"client app\", not \"consumer\""
metadata: 
  node_type: memory
  type: project
  originSessionId: d61853aa-021f-4c3f-bb78-dba73c675b21
  modified: 2026-09-03T01:15:23.641Z
---

The user renamed "consumer" to "client" throughout simplefin-aggregator's code and docs (e.g. `ConsumerAuth` → `ClientAuth`, `[consumer]` TOML section → `[client]`, `config.consumer` → `config.client`). When context alone doesn't make it clear which "client" is meant (HTTP client to a provider vs. the personal-finance app talking to this aggregator), the user writes "client app" for the latter.

**Why:** Personal terminology preference, stated directly ("I decided I didn't like 'consumer' and prefer 'client'"), no functional reason.

**How to apply:** Use "client"/"client app" (not "consumer") in any new code, comments, docs, or commit messages for this project. See also [[project_actual_budget_generic]] — the client app is generic, Actual Budget is just the motivating example.

Related wording, same instinct: a config `[[allowlist]]` entry is for **"a provider the built-in list does not name"**, not "a self-hosted provider". The user: "self-hosting is not the only reason to add a custom provider: there may be third-party providers that are not part of the known set." Calling it self-hosted tells the user with a real third-party bridge that the feature is not for them.
