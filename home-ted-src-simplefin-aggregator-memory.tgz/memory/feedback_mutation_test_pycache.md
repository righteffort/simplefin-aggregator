---
name: feedback-mutation-test-pycache
description: "Clear __pycache__ around every mutation-test cycle; CPython can silently reuse mutant bytecode"
metadata:
  node_type: memory
  type: feedback
---

When demonstrating a test is non-vacuous by mutating source and restoring it, delete `__pycache__` both before running the mutated code and after restoring the original: `find . -name __pycache__ -type d -prune -exec rm -rf {} +`.

**Why:** CPython validates a cached `.pyc` by source mtime-in-seconds plus size. A same-length mutation (e.g. `!a` → `!r`) restored within the same clock second leaves both unchanged, so the stale mutant bytecode is reused. Observed in simplefin-aggregator: a mutation was reported as "survived" (test passed) when the run had in fact executed the mutant after the restore — the mutation-test result was simply wrong, in the direction of false confidence.

**How to apply:** Wrap the mutate → run → restore loop in a clean step on both sides, and re-run the full suite from a clean cache before reporting mutation results. Relates to [[feedback-verification-suite]].
